from __future__ import annotations

import compileall
import pathlib
import sys


ROOT = pathlib.Path(__file__).resolve().parents[1]


def main() -> int:
    ok = compileall.compile_dir(ROOT / "bot_app", quiet=1)
    ok = compileall.compile_file(ROOT / "main.py", quiet=1) and ok
    if not ok:
        return 1
    print("Sintaxe Python verificada com sucesso.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
