from __future__ import annotations

from datetime import datetime, timezone
from zoneinfo import ZoneInfo

from telegram import InlineKeyboardButton, InlineKeyboardMarkup

from .currency import PaymentFee, format_brl, format_fee_percent
from .security import html_escape
from .status import status_label


PAGE_SIZE = 5
SAO_PAULO = ZoneInfo("America/Sao_Paulo")


def start_text() -> str:
    return "\n".join(
        [
            "💳 <b>GERADOR DE PAGAMENTOS</b>",
            "",
            "Olá! 👋",
            "",
            "Aqui você pode gerar uma cobrança PIX de forma rápida e segura.",
            "",
            "💰 Valor mínimo: <b>R$ 2,00</b>",
            "💰 Valor máximo: <b>R$ 500,00</b>",
            "",
            "Clique em uma opção abaixo.",
        ]
    )


def start_keyboard() -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(
        [
            [InlineKeyboardButton("💳 GERAR PAGAMENTO", callback_data="create_payment")],
            [InlineKeyboardButton("🔑 MINHA CHAVE PIX", callback_data="pix_menu")],
        ]
    )


def amount_question_text() -> str:
    return "\n".join(
        [
            "💰 <b>Qual valor você deseja cobrar?</b>",
            "",
            "Envie apenas o valor.",
            "",
            "Exemplos:",
            "<code>10</code>",
            "<code>25,50</code>",
            "<code>100,00</code>",
        ]
    )


def invalid_amount_text(reason: str) -> str:
    if reason == "min":
        return "❌ <b>Valor inválido</b>\n\nO valor mínimo para gerar um pagamento é <b>R$ 2,00</b>."
    if reason == "max":
        return "❌ <b>Valor inválido</b>\n\nO valor máximo para gerar um pagamento é <b>R$ 500,00</b>."
    return "⚠️ <b>Valor inválido</b>\n\nDigite um valor entre <b>R$ 2,00 e R$ 500,00</b>."


def help_text() -> str:
    return "\n".join(
        [
            "🆘 <b>AJUDA</b>",
            "",
            "Use /pagamento para gerar uma nova cobrança PIX.",
            "Use /pix para cadastrar, alterar, consultar ou remover sua chave PIX.",
            "Use /meuspagamentos para ver seu histórico.",
            "Use /cancelar para cancelar a operação atual.",
            "",
            "Valores aceitos:",
            "<code>10</code>",
            "<code>25,50</code>",
            "<code>100,00</code>",
            "",
            "💰 Mínimo: <b>R$ 2,00</b>",
            "💰 Máximo: <b>R$ 500,00</b>",
        ]
    )


def payment_confirmation_text(fee: PaymentFee) -> str:
    return "\n".join(
        [
            "📌 <b>CONFIRME O PAGAMENTO</b>",
            "",
            f"Valor solicitado: <b>{html_escape(format_brl(fee.requested_amount_cents))}</b>",
            f"Taxa: <b>{html_escape(format_fee_percent(fee.fee_basis_points))}</b>",
            f"Valor da taxa: <b>{html_escape(format_brl(fee.fee_amount_cents))}</b>",
            f"Valor líquido recebido: <b>{html_escape(format_brl(fee.net_amount_cents))}</b>",
            "",
            "Confirme para gerar o PIX copia e cola.",
        ]
    )


def payment_confirmation_keyboard() -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(
        [
            [InlineKeyboardButton("✅ CONFIRMAR", callback_data="confirm_payment")],
            [InlineKeyboardButton("❌ CANCELAR", callback_data="cancel_payment")],
        ]
    )


def payment_keyboard(payment: dict) -> InlineKeyboardMarkup:
    rows = []
    if payment.get("payment_link"):
        rows.append([InlineKeyboardButton("💳 PAGAR AGORA", url=payment["payment_link"])])
    rows.append([InlineKeyboardButton("🔍 VERIFICAR STATUS", callback_data=f"check_payment:{payment['id']}")])
    rows.append([InlineKeyboardButton("💳 GERAR OUTRO", callback_data="create_payment")])
    return InlineKeyboardMarkup(rows)


def payment_created_text(payment: dict) -> str:
    lines = [
        "✅ <b>PAGAMENTO GERADO!</b>",
        "",
        *_payment_amount_lines(payment),
        "",
        "🔗 Código PIX copia e cola:",
        f"<code>{html_escape(payment.get('pix_code') or '')}</code>",
        "",
        f"📌 Status: <b>{html_escape(status_label(payment['status']))}</b>",
        f"ID do pagamento: <code>{html_escape(payment['gateway_payment_id'])}</code>",
    ]
    return "\n".join(lines)


def payment_status_text(payment: dict, warning: str | None = None) -> str:
    lines = [
        "💳 <b>PAGAMENTO</b>",
        "",
        *_payment_amount_lines(payment),
        f"📌 Status: <b>{html_escape(status_label(payment['status']))}</b>",
        f"ID do pagamento: <code>{html_escape(payment['gateway_payment_id'])}</code>",
    ]
    if warning:
        lines.extend(["", warning])
    if payment.get("pix_code"):
        lines.extend(["", "🔗 Código PIX copia e cola:", f"<code>{html_escape(payment['pix_code'])}</code>"])
    return "\n".join(lines)


def history_text(payments: list[dict], total: int, page: int) -> str:
    if not payments:
        return "\n".join(
            [
                "📋 <b>MEUS PAGAMENTOS</b>",
                "",
                "Você ainda não gerou nenhum pagamento.",
                "",
                "Use /pagamento para criar sua primeira cobrança.",
            ]
        )

    lines = ["📋 <b>MEUS PAGAMENTOS</b>", "", f"Mostrando {len(payments)} de {total}.", ""]
    start = page * PAGE_SIZE + 1
    for index, payment in enumerate(payments, start=start):
        lines.extend(
            [
                f"<b>{index}.</b> {html_escape(format_brl(payment['amount_cents']))}",
                *_history_fee_lines(payment),
                f"Status: <b>{html_escape(status_label(payment['status']))}</b>",
                f"Criado em: {html_escape(format_date(payment['created_at']))}",
                f"ID: <code>{html_escape(payment['gateway_payment_id'])}</code>",
                "",
            ]
        )
    return "\n".join(lines).strip()


def history_keyboard(payments: list[dict], total: int, page: int) -> InlineKeyboardMarkup:
    rows = [
        [InlineKeyboardButton(f"🔍 Atualizar {page * PAGE_SIZE + index + 1}", callback_data=f"check_payment:{payment['id']}")]
        for index, payment in enumerate(payments)
    ]
    pagination = []
    if page > 0:
        pagination.append(InlineKeyboardButton("⬅️ Anterior", callback_data=f"history:{page - 1}"))
    if (page + 1) * PAGE_SIZE < total:
        pagination.append(InlineKeyboardButton("Próxima ➡️", callback_data=f"history:{page + 1}"))
    if pagination:
        rows.append(pagination)
    rows.append([InlineKeyboardButton("💳 GERAR PAGAMENTO", callback_data="create_payment")])
    return InlineKeyboardMarkup(rows)


def pix_menu_text(pix_key: dict | None) -> str:
    if not pix_key:
        return "\n".join(
            [
                "🔑 <b>MINHA CHAVE PIX</b>",
                "",
                "Nenhuma chave PIX cadastrada.",
            ]
        )

    return "\n".join(
        [
            "🔑 <b>MINHA CHAVE PIX</b>",
            "",
            f"Tipo: <b>{html_escape(pix_key['key_type'])}</b>",
            f"Chave: <code>{html_escape(pix_key['masked_key'])}</code>",
            f"Atualizada em: {html_escape(format_date(pix_key['updated_at']))}",
        ]
    )


def pix_keyboard(has_key: bool) -> InlineKeyboardMarkup:
    if not has_key:
        return InlineKeyboardMarkup([[InlineKeyboardButton("➕ CADASTRAR PIX", callback_data="pix_add")]])

    return InlineKeyboardMarkup(
        [
            [InlineKeyboardButton("✏️ ALTERAR PIX", callback_data="pix_add")],
            [InlineKeyboardButton("🗑 REMOVER PIX", callback_data="pix_remove")],
        ]
    )


def pix_key_question_text() -> str:
    return "\n".join(
        [
            "🔑 <b>Envie sua chave PIX</b>",
            "",
            "Tipos aceitos: CPF, CNPJ, e-mail, telefone com DDD ou chave aleatória UUID.",
            "",
            "A chave será exibida apenas mascarada depois de salva.",
        ]
    )


def invalid_pix_key_text(reason: str) -> str:
    return f"❌ <b>Chave PIX inválida</b>\n\n{html_escape(reason)}"


def pix_key_confirmation_text(pix_key) -> str:
    return "\n".join(
        [
            "📌 <b>CONFIRMAR CHAVE PIX</b>",
            "",
            f"Tipo: <b>{html_escape(pix_key.key_type)}</b>",
            f"Chave: <code>{html_escape(pix_key.masked)}</code>",
            "",
            "Confirme para salvar esta chave.",
        ]
    )


def pix_key_confirmation_keyboard() -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(
        [
            [InlineKeyboardButton("✅ SALVAR", callback_data="pix_save")],
            [InlineKeyboardButton("❌ CANCELAR", callback_data="pix_cancel")],
        ]
    )


def pix_remove_confirmation_text(pix_key: dict) -> str:
    return "\n".join(
        [
            "🗑 <b>REMOVER CHAVE PIX</b>",
            "",
            f"Chave: <code>{html_escape(pix_key['masked_key'])}</code>",
            "",
            "Confirme para remover sua chave cadastrada.",
        ]
    )


def pix_remove_keyboard() -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(
        [
            [InlineKeyboardButton("✅ REMOVER", callback_data="pix_remove_yes")],
            [InlineKeyboardButton("❌ CANCELAR", callback_data="pix_remove_no")],
        ]
    )


def format_date(value: str) -> str:
    try:
        parsed = datetime.fromisoformat(value.replace(" ", "T")).replace(tzinfo=timezone.utc)
        return parsed.astimezone(SAO_PAULO).strftime("%d/%m/%Y %H:%M")
    except Exception:
        return "-"


def _payment_amount_lines(payment: dict) -> list[str]:
    lines = [f"💰 Valor solicitado: <b>{html_escape(format_brl(payment['amount_cents']))}</b>"]
    if payment.get("fee_percent_basis_points"):
        lines.extend(
            [
                f"Taxa: <b>{html_escape(format_fee_percent(payment['fee_percent_basis_points']))}</b>",
                f"Valor da taxa: <b>{html_escape(format_brl(payment['fee_amount_cents']))}</b>",
                f"Valor líquido recebido: <b>{html_escape(format_brl(payment['net_amount_cents']))}</b>",
            ]
        )
    return lines


def _history_fee_lines(payment: dict) -> list[str]:
    if not payment.get("fee_percent_basis_points"):
        return []
    return [
        f"Líquido: <b>{html_escape(format_brl(payment['net_amount_cents']))}</b>",
        f"Taxa: {html_escape(format_fee_percent(payment['fee_percent_basis_points']))}",
    ]
