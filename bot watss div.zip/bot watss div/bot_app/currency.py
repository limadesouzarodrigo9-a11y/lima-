from __future__ import annotations

from dataclasses import dataclass
from decimal import Decimal, InvalidOperation, ROUND_HALF_UP
import re


MIN_AMOUNT_CENTS = 200
MAX_AMOUNT_CENTS = 50000
MIN_PAYMENT_FEE_BASIS_POINTS = 1500
MAX_PAYMENT_FEE_BASIS_POINTS = 2000
DEFAULT_PAYMENT_FEE_PERCENT = "15"

_AMOUNT_RE = re.compile(r"^(?:R\$\s*)?(\d{1,3})(?:([,.])(\d{1,2}))?$", re.IGNORECASE)


@dataclass(frozen=True)
class ParsedAmount:
    ok: bool
    amount_cents: int | None = None
    reason: str = "invalid"


@dataclass(frozen=True)
class PaymentFee:
    requested_amount_cents: int
    fee_basis_points: int
    fee_amount_cents: int
    net_amount_cents: int


def parse_amount(text: str | None) -> ParsedAmount:
    if not isinstance(text, str):
        return ParsedAmount(False)

    value = text.strip()
    if not value or len(value) > 20 or value.startswith("/"):
        return ParsedAmount(False)

    match = _AMOUNT_RE.fullmatch(value)
    if not match:
        return ParsedAmount(False)

    reais = int(match.group(1))
    cents_text = (match.group(3) or "").ljust(2, "0")
    centavos = int(cents_text or "0")
    amount_cents = reais * 100 + centavos

    if amount_cents < MIN_AMOUNT_CENTS:
        return ParsedAmount(False, reason="min")
    if amount_cents > MAX_AMOUNT_CENTS:
        return ParsedAmount(False, reason="max")

    return ParsedAmount(True, amount_cents=amount_cents, reason="")


def format_brl(amount_cents: int) -> str:
    reais = Decimal(amount_cents) / Decimal(100)
    formatted = f"{reais:,.2f}".replace(",", "X").replace(".", ",").replace("X", ".")
    return f"R$ {formatted}"


def format_for_gateway(amount_cents: int) -> str:
    return f"{Decimal(amount_cents) / Decimal(100):.2f}"


def parse_fee_percent_to_basis_points(value: str | None) -> int:
    raw_value = value if value not in (None, "") else DEFAULT_PAYMENT_FEE_PERCENT
    text = str(raw_value).strip().replace("%", "").replace(",", ".")
    try:
        percent = Decimal(text)
    except InvalidOperation as exc:
        raise ValueError("PAYMENT_FEE_PERCENT deve ser um numero entre 15 e 20.") from exc

    basis_points = int((percent * Decimal(100)).quantize(Decimal("1"), rounding=ROUND_HALF_UP))
    if basis_points < MIN_PAYMENT_FEE_BASIS_POINTS or basis_points > MAX_PAYMENT_FEE_BASIS_POINTS:
        raise ValueError("PAYMENT_FEE_PERCENT deve estar entre 15 e 20.")
    return basis_points


def calculate_payment_fee(amount_cents: int, fee_basis_points: int) -> PaymentFee:
    if amount_cents < 0:
        raise ValueError("Valor nao pode ser negativo.")
    if fee_basis_points < MIN_PAYMENT_FEE_BASIS_POINTS or fee_basis_points > MAX_PAYMENT_FEE_BASIS_POINTS:
        raise ValueError("Percentual de taxa fora dos limites permitidos.")

    fee = (Decimal(amount_cents) * Decimal(fee_basis_points) / Decimal(10000)).quantize(
        Decimal("1"),
        rounding=ROUND_HALF_UP,
    )
    fee_amount_cents = int(fee)
    return PaymentFee(
        requested_amount_cents=amount_cents,
        fee_basis_points=fee_basis_points,
        fee_amount_cents=fee_amount_cents,
        net_amount_cents=amount_cents - fee_amount_cents,
    )


def format_fee_percent(fee_basis_points: int) -> str:
    percent = Decimal(fee_basis_points) / Decimal(100)
    text = f"{percent:.2f}".rstrip("0").rstrip(".").replace(".", ",")
    return f"{text}%"
