from __future__ import annotations

import html
import logging
import os
import time
from collections import defaultdict, deque
from dataclasses import dataclass
from typing import Deque


class RedactSecretsFilter(logging.Filter):
    def filter(self, record: logging.LogRecord) -> bool:
        secrets = [
            os.getenv("TELEGRAM_BOT_TOKEN", ""),
            os.getenv("PAYMENT_API_KEY", ""),
            os.getenv("PAYMENT_WEBHOOK_SECRET", ""),
            os.getenv("PIX_KEY_ENCRYPTION_SECRET", ""),
        ]
        message = record.getMessage()
        for secret in secrets:
            if secret:
                message = message.replace(secret, "[REDACTED]")
        record.msg = message
        record.args = ()
        return True


def setup_logging(config) -> None:
    logging.basicConfig(
        level=getattr(logging, config.log_level, logging.INFO),
        format="[%(asctime)s] %(levelname)s %(name)s: %(message)s",
    )
    redact_filter = RedactSecretsFilter()
    root_logger = logging.getLogger()
    root_logger.addFilter(redact_filter)
    for handler in root_logger.handlers:
        handler.addFilter(redact_filter)
    logging.getLogger("httpx").setLevel(logging.WARNING)
    logging.getLogger("httpcore").setLevel(logging.WARNING)
    logging.getLogger("telegram").setLevel(logging.WARNING)
    logging.getLogger("aiohttp.access").setLevel(logging.WARNING)


def get_logger(name: str) -> logging.Logger:
    return logging.getLogger(name)


def clean_text(value: object, max_length: int = 128) -> str:
    text = str(value or "").strip()
    text = "".join(ch for ch in text if ch >= " " and ch != "\x7f")
    return text[:max_length]


def html_escape(value: object) -> str:
    return html.escape(str(value or ""), quote=True)


@dataclass
class TelegramUser:
    user_id: str
    username: str | None
    name: str | None


def telegram_user_from_update_user(user) -> TelegramUser:
    first_name = clean_text(getattr(user, "first_name", ""), 64)
    last_name = clean_text(getattr(user, "last_name", ""), 64)
    full_name = clean_text(" ".join(part for part in [first_name, last_name] if part), 128)
    username = clean_text(getattr(user, "username", ""), 64)
    return TelegramUser(
        user_id=str(getattr(user, "id", "")),
        username=username or None,
        name=full_name or None,
    )


class UserRateLimiter:
    def __init__(self, window_seconds: int = 60, max_events: int = 20, warning_seconds: int = 10):
        self.window_seconds = window_seconds
        self.max_events = max_events
        self.warning_seconds = warning_seconds
        self._events: dict[str, Deque[float]] = defaultdict(deque)
        self._last_warning: dict[str, float] = {}

    def hit(self, user_id: str) -> tuple[bool, bool]:
        now = time.monotonic()
        events = self._events[user_id]
        while events and now - events[0] > self.window_seconds:
            events.popleft()

        if len(events) >= self.max_events:
            last_warning = self._last_warning.get(user_id, 0)
            should_warn = now - last_warning > self.warning_seconds
            if should_warn:
                self._last_warning[user_id] = now
            return False, should_warn

        events.append(now)
        return True, False
