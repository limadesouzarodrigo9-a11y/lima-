from __future__ import annotations

from dataclasses import dataclass
from typing import Any

import httpx

from .currency import format_for_gateway
from .security import get_logger


logger = get_logger(__name__)


class PaymentGatewayError(RuntimeError):
    pass


@dataclass(frozen=True)
class CreatedPix:
    pix_id: str
    pix_code: str
    raw: dict[str, Any]


@dataclass(frozen=True)
class PixStatus:
    status: str
    raw: dict[str, Any]


class ApiStatusLogger:
    def __init__(self):
        self._state: str | None = None
        self._last_problem: str | None = None

    def ok(self) -> None:
        if self._state != "ok":
            logger.info("✅ API funcionando normalmente")
        self._state = "ok"
        self._last_problem = None

    def error(self, problem: str) -> None:
        if self._state != "error" or self._last_problem != problem:
            logger.error("❌ Erro na API: %s", problem)
        self._state = "error"
        self._last_problem = problem


class AmazingPayClient:
    def __init__(self, base_url: str, api_key: str, timeout_seconds: float = 15.0):
        self.base_url = base_url.rstrip("/")
        self.api_key = api_key
        self._client = httpx.AsyncClient(base_url=self.base_url, timeout=timeout_seconds)
        self._api_status = ApiStatusLogger()

    async def __aenter__(self) -> "AmazingPayClient":
        return self

    async def __aexit__(self, *_args) -> None:
        await self.close()

    async def close(self) -> None:
        await self._client.aclose()

    async def create_pix(self, amount_cents: int) -> CreatedPix:
        data = await self._get(
            "/createPix",
            params={"value": format_for_gateway(amount_cents)},
        )
        pix_code = str(data.get("code") or "")
        pix_id = str(data.get("pixId") or "")

        if not pix_code or not pix_id:
            self._api_status.error("resposta invalida da API ao criar PIX")
            raise PaymentGatewayError("Resposta invalida da AmazingPay ao criar PIX.")

        return CreatedPix(pix_id=pix_id, pix_code=pix_code, raw=data)

    async def get_pix_status(self, pix_id: str) -> PixStatus:
        data = await self._get(f"/pix/{pix_id}", params={})
        status = str(data.get("status") or "")

        if not status:
            self._api_status.error("resposta invalida da API ao consultar PIX")
            raise PaymentGatewayError("Resposta invalida da AmazingPay ao consultar PIX.")

        return PixStatus(status=status, raw=data)

    async def _get(self, path: str, params: dict[str, Any]) -> dict[str, Any]:
        try:
            response = await self._client.get(
                path,
                params={"apiKey": self.api_key, **params},
            )
            response.raise_for_status()
            data = response.json()
        except httpx.TimeoutException as exc:
            problem = "timeout ao conectar com a API"
            self._api_status.error(problem)
            raise PaymentGatewayError(problem) from exc
        except httpx.HTTPStatusError as exc:
            problem = f"erro HTTP {exc.response.status_code} retornado pela API"
            self._api_status.error(problem)
            raise PaymentGatewayError(problem) from exc
        except httpx.RequestError as exc:
            problem = "falha de conexao com a API"
            self._api_status.error(problem)
            raise PaymentGatewayError(problem) from exc
        except ValueError as exc:
            problem = "resposta invalida da API"
            self._api_status.error(problem)
            raise PaymentGatewayError(problem) from exc

        if not isinstance(data, dict):
            problem = "resposta invalida da API"
            self._api_status.error(problem)
            raise PaymentGatewayError(problem)

        self._api_status.ok()
        return data
