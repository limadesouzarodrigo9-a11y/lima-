from __future__ import annotations

import base64
import hashlib
import hmac
import re
import uuid
from dataclasses import dataclass

from cryptography.fernet import Fernet

from .security import clean_text


PIX_KEY_TYPES = {"CPF", "CNPJ", "EMAIL", "PHONE", "EVP"}

_EMAIL_RE = re.compile(r"^[A-Z0-9._%+-]{1,64}@[A-Z0-9.-]{1,253}\.[A-Z]{2,63}$", re.IGNORECASE)


class PixKeyValidationError(ValueError):
    pass


class PixKeySecurityError(RuntimeError):
    pass


@dataclass(frozen=True)
class ValidatedPixKey:
    key_type: str
    normalized: str
    masked: str


class PixKeyCipher:
    def __init__(self, secret: str):
        if len(secret) < 32:
            raise PixKeySecurityError("PIX_KEY_ENCRYPTION_SECRET deve ter pelo menos 32 caracteres.")

        encryption_key = base64.urlsafe_b64encode(hashlib.sha256(secret.encode("utf-8")).digest())
        self._fernet = Fernet(encryption_key)
        self._digest_key = hashlib.sha256(f"pix-key-digest:{secret}".encode("utf-8")).digest()

    def encrypt(self, value: str) -> str:
        return self._fernet.encrypt(value.encode("utf-8")).decode("ascii")

    def decrypt(self, value: str) -> str:
        return self._fernet.decrypt(value.encode("ascii")).decode("utf-8")

    def digest(self, value: str) -> str:
        return hmac.new(self._digest_key, value.encode("utf-8"), hashlib.sha256).hexdigest()


def validate_pix_key(value: str | None) -> ValidatedPixKey:
    text = clean_text(value, 140)
    if not text:
        raise PixKeyValidationError("Informe uma chave PIX.")

    if _EMAIL_RE.fullmatch(text):
        normalized = text.lower()
        return ValidatedPixKey("EMAIL", normalized, _mask_email(normalized))

    if _is_uuid(text):
        normalized = str(uuid.UUID(text))
        return ValidatedPixKey("EVP", normalized, _mask_generic(normalized, 8, 4))

    digits = re.sub(r"\D", "", text)
    if len(digits) == 11 and _valid_cpf(digits):
        return ValidatedPixKey("CPF", digits, f"***.***.***-{digits[-2:]}")

    if len(digits) == 14 and _valid_cnpj(digits):
        return ValidatedPixKey("CNPJ", digits, f"**.***.***/****-{digits[-2:]}")

    phone = _normalize_phone(text, digits)
    if phone:
        return ValidatedPixKey("PHONE", phone, _mask_generic(phone, 3, 4))

    raise PixKeyValidationError(
        "Chave PIX invalida. Use CPF, CNPJ, e-mail, telefone com DDD ou chave aleatoria UUID."
    )


def _is_uuid(value: str) -> bool:
    try:
        uuid.UUID(value)
    except (TypeError, ValueError):
        return False
    return True


def _normalize_phone(text: str, digits: str) -> str | None:
    compact = text.replace(" ", "")
    if compact.startswith("+"):
        phone_digits = re.sub(r"\D", "", compact)
        if phone_digits.startswith("55") and len(phone_digits) in {12, 13}:
            return f"+{phone_digits}"
        return None

    if digits.startswith("55") and len(digits) in {12, 13}:
        return f"+{digits}"
    if len(digits) in {10, 11}:
        return f"+55{digits}"
    return None


def _valid_cpf(value: str) -> bool:
    if len(value) != 11 or len(set(value)) == 1:
        return False

    numbers = [int(char) for char in value]
    first = sum(numbers[index] * (10 - index) for index in range(9))
    first_digit = (first * 10) % 11
    if first_digit == 10:
        first_digit = 0

    second = sum(numbers[index] * (11 - index) for index in range(10))
    second_digit = (second * 10) % 11
    if second_digit == 10:
        second_digit = 0

    return numbers[9] == first_digit and numbers[10] == second_digit


def _valid_cnpj(value: str) -> bool:
    if len(value) != 14 or len(set(value)) == 1:
        return False

    numbers = [int(char) for char in value]
    first_weights = [5, 4, 3, 2, 9, 8, 7, 6, 5, 4, 3, 2]
    second_weights = [6, *first_weights]

    first_sum = sum(number * weight for number, weight in zip(numbers[:12], first_weights))
    first_digit = 11 - (first_sum % 11)
    if first_digit >= 10:
        first_digit = 0

    second_sum = sum(number * weight for number, weight in zip(numbers[:13], second_weights))
    second_digit = 11 - (second_sum % 11)
    if second_digit >= 10:
        second_digit = 0

    return numbers[12] == first_digit and numbers[13] == second_digit


def _mask_email(value: str) -> str:
    local, domain = value.split("@", 1)
    if len(local) <= 2:
        masked_local = f"{local[:1]}***"
    else:
        masked_local = f"{local[:2]}***"
    return f"{masked_local}@{domain}"


def _mask_generic(value: str, visible_start: int, visible_end: int) -> str:
    if len(value) <= visible_start + visible_end:
        return "*" * len(value)
    return f"{value[:visible_start]}***{value[-visible_end:]}"
