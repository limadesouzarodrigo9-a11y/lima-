from __future__ import annotations

from enum import StrEnum


class PaymentStatus(StrEnum):
    PENDING = "PENDING"
    PAID = "PAID"
    EXPIRED = "EXPIRED"
    CANCELLED = "CANCELLED"
    FAILED = "FAILED"


def map_gateway_status(status: str | None) -> PaymentStatus | None:
    normalized = (status or "").strip().lower()
    if normalized == "waiting":
        return PaymentStatus.PENDING
    if normalized == "verified":
        return PaymentStatus.PAID
    if normalized == "expired":
        return PaymentStatus.EXPIRED
    if normalized in {"cancelled", "canceled"}:
        return PaymentStatus.CANCELLED
    if normalized in {"failed", "error"}:
        return PaymentStatus.FAILED
    return None


def status_label(status: str | PaymentStatus) -> str:
    value = PaymentStatus(status)
    labels = {
        PaymentStatus.PENDING: "⏳ Pendente",
        PaymentStatus.PAID: "✅ Pago",
        PaymentStatus.EXPIRED: "❌ Expirado",
        PaymentStatus.CANCELLED: "🚫 Cancelado",
        PaymentStatus.FAILED: "⚠️ Falhou",
    }
    return labels[value]


def is_final_status(status: str | PaymentStatus) -> bool:
    return PaymentStatus(status) in {
        PaymentStatus.PAID,
        PaymentStatus.EXPIRED,
        PaymentStatus.CANCELLED,
        PaymentStatus.FAILED,
    }


def resolve_transition(current_status: str, next_status: PaymentStatus | None) -> PaymentStatus:
    current = PaymentStatus(current_status)
    if next_status is None:
        return current
    if current == PaymentStatus.PAID:
        return current
    if is_final_status(current) and next_status == PaymentStatus.PENDING:
        return current
    return next_status
