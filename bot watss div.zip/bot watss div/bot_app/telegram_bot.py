from __future__ import annotations

from telegram import Update
from telegram.constants import ParseMode
from telegram.ext import (
    Application,
    ApplicationBuilder,
    ApplicationHandlerStop,
    CallbackQueryHandler,
    CommandHandler,
    ContextTypes,
    MessageHandler,
    TypeHandler,
    filters,
)

from .amazingpay import PaymentGatewayError
from .currency import parse_amount
from .messages import (
    PAGE_SIZE,
    amount_question_text,
    help_text,
    history_keyboard,
    history_text,
    invalid_amount_text,
    invalid_pix_key_text,
    payment_confirmation_keyboard,
    payment_confirmation_text,
    payment_created_text,
    payment_keyboard,
    payment_status_text,
    pix_key_confirmation_keyboard,
    pix_key_confirmation_text,
    pix_key_question_text,
    pix_keyboard,
    pix_menu_text,
    pix_remove_confirmation_text,
    pix_remove_keyboard,
    start_keyboard,
    start_text,
)
from .pix import PixKeyValidationError
from .security import UserRateLimiter, get_logger, telegram_user_from_update_user


logger = get_logger(__name__)


def build_application(config, payment_service) -> Application:
    application = ApplicationBuilder().token(config.telegram_bot_token).build()
    limiter = UserRateLimiter()

    def clear_payment_flow(context: ContextTypes.DEFAULT_TYPE) -> None:
        context.user_data["awaiting_amount"] = False
        context.user_data.pop("pending_payment", None)

    def clear_pix_flow(context: ContextTypes.DEFAULT_TYPE) -> None:
        context.user_data["awaiting_pix_key"] = False
        context.user_data.pop("pending_pix_key", None)

    def clear_all_flows(context: ContextTypes.DEFAULT_TYPE) -> None:
        clear_payment_flow(context)
        clear_pix_flow(context)

    async def rate_limit_gate(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
        user = update.effective_user
        if not user:
            return
        allowed, warn = limiter.hit(str(user.id))
        if allowed:
            return
        if warn and update.effective_chat:
            await context.bot.send_message(
                chat_id=update.effective_chat.id,
                text="⏳ Muitas mensagens em pouco tempo. Aguarde alguns segundos e tente novamente.",
            )
        raise ApplicationHandlerStop

    async def start(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
        clear_all_flows(context)
        await update.effective_message.reply_html(start_text(), reply_markup=start_keyboard())

    async def help_command(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
        await update.effective_message.reply_html(help_text())

    async def cancel(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
        clear_all_flows(context)
        await update.effective_message.reply_text(
            "✅ Operação cancelada. Use /pagamento para criar uma cobrança ou /pix para gerenciar sua chave."
        )

    async def ask_amount(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
        clear_pix_flow(context)
        context.user_data["awaiting_amount"] = True
        context.user_data.pop("pending_payment", None)
        await update.effective_message.reply_html(amount_question_text())

    async def create_payment_callback(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
        query = update.callback_query
        await query.answer()
        clear_pix_flow(context)
        context.user_data["awaiting_amount"] = True
        context.user_data.pop("pending_payment", None)
        await query.message.reply_html(amount_question_text())

    async def amount_text(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
        parsed = parse_amount(update.effective_message.text)
        if not parsed.ok:
            await update.effective_message.reply_html(invalid_amount_text(parsed.reason))
            return

        clear_pix_flow(context)
        context.user_data["awaiting_amount"] = False
        context.user_data["pending_payment"] = {
            "amount_cents": parsed.amount_cents,
            "idempotency_key": f"{update.effective_user.id}:{update.update_id}:create-pix",
        }
        fee = payment_service.calculate_fee(parsed.amount_cents)
        await update.effective_message.reply_html(
            payment_confirmation_text(fee),
            reply_markup=payment_confirmation_keyboard(),
        )

    async def confirm_payment_callback(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
        query = update.callback_query
        await query.answer()

        pending = context.user_data.get("pending_payment")
        if not pending:
            await query.message.reply_text("Nenhum pagamento pendente para confirmar. Use /pagamento.")
            return

        await query.message.reply_text("⏳ Criando pagamento...")
        try:
            telegram_user = telegram_user_from_update_user(update.effective_user)
            payment = await payment_service.create_for_telegram_user(
                telegram_user=telegram_user,
                amount_cents=int(pending["amount_cents"]),
                idempotency_key=str(pending["idempotency_key"]),
            )
            clear_payment_flow(context)
            await query.message.reply_html(
                payment_created_text(payment),
                reply_markup=payment_keyboard(payment),
            )
        except PaymentGatewayError:
            logger.exception("Falha no gateway ao criar pagamento.")
            await query.message.reply_html(
                "⚠️ <b>Não foi possível criar o pagamento</b>\n\nTente novamente em alguns instantes."
            )
        except Exception:
            logger.exception("Falha inesperada ao criar pagamento.")
            await query.message.reply_html(
                "⚠️ <b>Não foi possível criar o pagamento</b>\n\nTente novamente em alguns instantes."
            )

    async def cancel_payment_callback(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
        query = update.callback_query
        await query.answer()
        clear_payment_flow(context)
        await query.message.reply_text("✅ Pagamento cancelado.")

    async def check_payment(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
        query = update.callback_query
        await query.answer("Consultando status...")
        payment_id = int(query.data.split(":", 1)[1])
        user_payment = await payment_service.get_for_user(payment_id, update.effective_user.id)

        if not user_payment:
            await query.message.reply_text("Pagamento não encontrado para seu usuário.")
            return

        try:
            result = await payment_service.refresh_payment(payment_id, "telegram-button")
            payment = result.payment or user_payment
            await query.message.reply_html(payment_status_text(payment), reply_markup=payment_keyboard(payment))
        except PaymentGatewayError:
            logger.exception("Falha ao consultar status no gateway.")
            await query.message.reply_html(
                payment_status_text(
                    user_payment,
                    "⚠️ Não foi possível atualizar o status agora. Tente novamente em alguns instantes.",
                ),
                reply_markup=payment_keyboard(user_payment),
            )

    async def my_payments(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
        await send_history(update, context, page=0, edit=False)

    async def history_page(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
        query = update.callback_query
        await query.answer()
        page = int(query.data.split(":", 1)[1])
        await send_history(update, context, page=page, edit=True)

    async def send_history(
        update: Update,
        context: ContextTypes.DEFAULT_TYPE,
        page: int,
        edit: bool,
    ) -> None:
        payments, total = await payment_service.list_for_user(
            update.effective_user.id,
            limit=PAGE_SIZE,
            offset=page * PAGE_SIZE,
        )
        text = history_text(payments, total, page)
        keyboard = history_keyboard(payments, total, page)

        if edit and update.callback_query:
            await update.callback_query.edit_message_text(
                text,
                parse_mode=ParseMode.HTML,
                reply_markup=keyboard,
            )
            return

        await update.effective_message.reply_html(text, reply_markup=keyboard)

    async def pix_command(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
        clear_all_flows(context)
        await send_pix_menu(update, context, edit=False)

    async def pix_menu_callback(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
        query = update.callback_query
        await query.answer()
        clear_all_flows(context)
        await send_pix_menu(update, context, edit=True)

    async def send_pix_menu(update: Update, context: ContextTypes.DEFAULT_TYPE, edit: bool) -> None:
        pix_key = await payment_service.get_pix_key(update.effective_user.id)
        text = pix_menu_text(pix_key)
        keyboard = pix_keyboard(bool(pix_key))

        if edit and update.callback_query:
            await update.callback_query.edit_message_text(
                text,
                parse_mode=ParseMode.HTML,
                reply_markup=keyboard,
            )
            return

        await update.effective_message.reply_html(text, reply_markup=keyboard)

    async def pix_add_callback(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
        query = update.callback_query
        await query.answer()
        clear_payment_flow(context)
        context.user_data["awaiting_pix_key"] = True
        context.user_data.pop("pending_pix_key", None)
        await query.message.reply_html(pix_key_question_text())

    async def pix_key_text(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
        try:
            pix_key = payment_service.validate_pix_key(update.effective_message.text)
        except PixKeyValidationError as exc:
            await update.effective_message.reply_html(invalid_pix_key_text(str(exc)))
            return

        context.user_data["awaiting_pix_key"] = False
        context.user_data["pending_pix_key"] = pix_key
        await update.effective_message.reply_html(
            pix_key_confirmation_text(pix_key),
            reply_markup=pix_key_confirmation_keyboard(),
        )

    async def pix_save_callback(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
        query = update.callback_query
        await query.answer()

        pix_key = context.user_data.get("pending_pix_key")
        if not pix_key:
            await query.message.reply_text("Nenhuma chave PIX pendente para salvar. Use /pix.")
            return

        try:
            telegram_user = telegram_user_from_update_user(update.effective_user)
            saved = await payment_service.save_pix_key(telegram_user, pix_key)
            clear_pix_flow(context)
            await query.message.reply_html(
                "✅ <b>Chave PIX salva com segurança.</b>\n\n"
                f"Chave cadastrada: <code>{saved['masked_key']}</code>",
                reply_markup=pix_keyboard(True),
            )
        except Exception:
            logger.exception("Falha ao salvar chave PIX.")
            await query.message.reply_html(
                "⚠️ <b>Não foi possível salvar sua chave PIX.</b>\n\nTente novamente em alguns instantes."
            )

    async def pix_cancel_callback(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
        query = update.callback_query
        await query.answer()
        clear_pix_flow(context)
        await query.message.reply_text("✅ Cadastro de PIX cancelado.")

    async def pix_remove_callback(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
        query = update.callback_query
        await query.answer()
        pix_key = await payment_service.get_pix_key(update.effective_user.id)
        if not pix_key:
            await query.message.reply_text("Você ainda não possui chave PIX cadastrada.")
            return

        await query.message.reply_html(
            pix_remove_confirmation_text(pix_key),
            reply_markup=pix_remove_keyboard(),
        )

    async def pix_remove_yes_callback(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
        query = update.callback_query
        await query.answer()
        removed = await payment_service.remove_pix_key(update.effective_user.id)
        clear_pix_flow(context)
        if removed:
            await query.message.reply_text("✅ Chave PIX removida.")
            return
        await query.message.reply_text("Você ainda não possui chave PIX cadastrada.")

    async def pix_remove_no_callback(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
        query = update.callback_query
        await query.answer()
        await query.message.reply_text("✅ Remoção cancelada.")

    async def text_message(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
        if context.user_data.get("awaiting_pix_key"):
            await pix_key_text(update, context)
            return
        if context.user_data.get("awaiting_amount"):
            await amount_text(update, context)
            return

        await update.effective_message.reply_text(
            "Use /pagamento para criar uma cobrança, /pix para gerenciar sua chave ou /ajuda para ver as instruções."
        )

    async def on_error(update: object, context: ContextTypes.DEFAULT_TYPE) -> None:
        logger.exception("Erro em handler do Telegram.", exc_info=context.error)
        if isinstance(update, Update) and update.effective_message:
            try:
                await update.effective_message.reply_text(
                    "⚠️ Ocorreu um erro inesperado. Tente novamente em alguns instantes."
                )
            except Exception:
                logger.warning("Nao foi possivel responder erro ao usuario.", exc_info=True)

    application.add_handler(TypeHandler(Update, rate_limit_gate), group=-1)
    application.add_handler(CommandHandler("start", start))
    application.add_handler(CommandHandler("ajuda", help_command))
    application.add_handler(CommandHandler("cancelar", cancel))
    application.add_handler(CommandHandler("pagamento", ask_amount))
    application.add_handler(CommandHandler("meuspagamentos", my_payments))
    application.add_handler(CommandHandler(["pix", "chavepix"], pix_command))
    application.add_handler(CallbackQueryHandler(create_payment_callback, pattern=r"^create_payment$"))
    application.add_handler(CallbackQueryHandler(confirm_payment_callback, pattern=r"^confirm_payment$"))
    application.add_handler(CallbackQueryHandler(cancel_payment_callback, pattern=r"^cancel_payment$"))
    application.add_handler(CallbackQueryHandler(check_payment, pattern=r"^check_payment:\d+$"))
    application.add_handler(CallbackQueryHandler(history_page, pattern=r"^history:\d+$"))
    application.add_handler(CallbackQueryHandler(pix_menu_callback, pattern=r"^pix_menu$"))
    application.add_handler(CallbackQueryHandler(pix_add_callback, pattern=r"^pix_add$"))
    application.add_handler(CallbackQueryHandler(pix_save_callback, pattern=r"^pix_save$"))
    application.add_handler(CallbackQueryHandler(pix_cancel_callback, pattern=r"^pix_cancel$"))
    application.add_handler(CallbackQueryHandler(pix_remove_callback, pattern=r"^pix_remove$"))
    application.add_handler(CallbackQueryHandler(pix_remove_yes_callback, pattern=r"^pix_remove_yes$"))
    application.add_handler(CallbackQueryHandler(pix_remove_no_callback, pattern=r"^pix_remove_no$"))
    application.add_handler(MessageHandler(filters.TEXT & ~filters.COMMAND, text_message))
    application.add_error_handler(on_error)

    return application
