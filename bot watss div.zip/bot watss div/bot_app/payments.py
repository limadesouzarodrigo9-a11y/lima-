from __future__ import annotations

import asyncio
from dataclasses import dataclass
from typing import Any

from .currency import MAX_AMOUNT_CENTS, MIN_AMOUNT_CENTS, PaymentFee, calculate_payment_fee
from .database import PaymentRepository
from .pix import PixKeyCipher, ValidatedPixKey, validate_pix_key
from .security import TelegramUser
from .status import PaymentStatus, map_gateway_status, resolve_transition


@dataclass(frozen=True)
class StatusResult:
    payment: dict[str, Any] | None
    previous_status: str | None
    changed: bool


class PaymentService:
    def __init__(self, repository: PaymentRepository, client, config):
        self.repository = repository
        self.client = client
        self.fee_basis_points = config.payment_fee_basis_points
        self._pix_cipher = PixKeyCipher(config.pix_key_encryption_secret)
        self._in_flight: dict[str, asyncio.Task] = {}

    def calculate_fee(self, amount_cents: int) -> PaymentFee:
        return calculate_payment_fee(amount_cents, self.fee_basis_points)

    def validate_pix_key(self, value: str | None) -> ValidatedPixKey:
        return validate_pix_key(value)

    async def get_pix_key(self, user_id: int | str) -> dict[str, Any] | None:
        return await self.repository.get_pix_key(user_id)

    async def save_pix_key(
        self,
        telegram_user: TelegramUser,
        pix_key: ValidatedPixKey,
    ) -> dict[str, Any]:
        return await self.repository.upsert_pix_key(
            {
                "telegram_user_id": telegram_user.user_id,
                "telegram_username": telegram_user.username,
                "telegram_name": telegram_user.name,
                "key_type": pix_key.key_type,
                "encrypted_key": self._pix_cipher.encrypt(pix_key.normalized),
                "key_hash": self._pix_cipher.digest(pix_key.normalized),
                "masked_key": pix_key.masked,
            }
        )

    async def remove_pix_key(self, user_id: int | str) -> bool:
        return await self.repository.delete_pix_key(user_id)

    async def create_for_telegram_user(
        self,
        telegram_user: TelegramUser,
        amount_cents: int,
        idempotency_key: str,
    ) -> dict[str, Any]:
        if not isinstance(amount_cents, int):
            raise ValueError("Valor deve estar em centavos.")
        if amount_cents < MIN_AMOUNT_CENTS or amount_cents > MAX_AMOUNT_CENTS:
            raise ValueError("Valor fora dos limites permitidos.")

        existing = await self.repository.get_by_idempotency_key(idempotency_key)
        if existing:
            return existing

        task = self._in_flight.get(idempotency_key)
        if task:
            return await task

        task = asyncio.create_task(
            self._create_after_gateway_call(telegram_user, amount_cents, idempotency_key)
        )
        self._in_flight[idempotency_key] = task
        try:
            return await task
        finally:
            self._in_flight.pop(idempotency_key, None)

    async def _create_after_gateway_call(
        self,
        telegram_user: TelegramUser,
        amount_cents: int,
        idempotency_key: str,
    ) -> dict[str, Any]:
        fee = self.calculate_fee(amount_cents)
        pix = await self.client.create_pix(amount_cents)
        duplicate = await self.repository.get_by_gateway_payment_id(pix.pix_id)
        if duplicate:
            return duplicate

        return await self.repository.create_payment(
            {
                "telegram_user_id": telegram_user.user_id,
                "telegram_username": telegram_user.username,
                "telegram_name": telegram_user.name,
                "amount_cents": amount_cents,
                "fee_percent_basis_points": fee.fee_basis_points,
                "fee_amount_cents": fee.fee_amount_cents,
                "net_amount_cents": fee.net_amount_cents,
                "gateway_payment_id": pix.pix_id,
                "payment_link": None,
                "pix_code": pix.pix_code,
                "status": PaymentStatus.PENDING.value,
                "idempotency_key": idempotency_key,
                "raw_gateway_response": pix.raw,
            }
        )

    async def refresh_payment(self, payment_id: int, source: str = "manual") -> StatusResult:
        payment = await self.repository.get_by_id(payment_id)
        if not payment:
            return StatusResult(None, None, False)

        if payment["status"] != PaymentStatus.PENDING.value:
            return StatusResult(payment, payment["status"], False)

        gateway_status = await self.client.get_pix_status(payment["gateway_payment_id"])
        return await self.apply_gateway_status(
            payment["gateway_payment_id"],
            gateway_status.status,
            source,
            gateway_status.raw,
        )

    async def apply_gateway_status(
        self,
        pix_id: str,
        gateway_status: str,
        source: str,
        payload: Any = None,
    ) -> StatusResult:
        payment = await self.repository.get_by_gateway_payment_id(pix_id)
        if not payment:
            return StatusResult(None, None, False)

        mapped = map_gateway_status(gateway_status)
        next_status = resolve_transition(payment["status"], mapped)

        if payment["status"] == next_status.value:
            return StatusResult(payment, payment["status"], False)

        updated = await self.repository.update_status(payment["id"], next_status, source, payload)
        return StatusResult(updated, payment["status"], True)

    async def list_for_user(self, user_id: int | str, limit: int, offset: int) -> tuple[list[dict], int]:
        payments = await self.repository.list_for_user(user_id, limit, offset)
        total = await self.repository.count_for_user(user_id)
        return payments, total

    async def get_for_user(self, payment_id: int, user_id: int | str) -> dict | None:
        return await self.repository.get_for_user(payment_id, user_id)

    async def list_pending(self, limit: int) -> list[dict]:
        return await self.repository.list_pending(limit)
