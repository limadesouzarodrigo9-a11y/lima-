from __future__ import annotations

import asyncio

from telegram.constants import ParseMode

from .amazingpay import PaymentGatewayError
from .currency import format_brl, format_fee_percent
from .security import get_logger, html_escape
from .status import PaymentStatus, is_final_status, status_label


logger = get_logger(__name__)


class StatusPoller:
    def __init__(self, config, payment_service, bot):
        self.config = config
        self.payment_service = payment_service
        self.bot = bot
        self._task: asyncio.Task | None = None

    def start(self) -> None:
        interval = self.config.payment_status_poll_interval_seconds
        if interval <= 0:
            logger.info("Consulta automatica de pagamentos desativada.")
            return
        self._task = asyncio.create_task(self._run())
        logger.info("Consulta automatica iniciada a cada %s segundos.", interval)

    async def stop(self) -> None:
        if not self._task:
            return
        self._task.cancel()
        try:
            await self._task
        except asyncio.CancelledError:
            pass

    async def _run(self) -> None:
        await asyncio.sleep(5)
        while True:
            await self._tick()
            await asyncio.sleep(self.config.payment_status_poll_interval_seconds)

    async def _tick(self) -> None:
        try:
            payments = await self.payment_service.list_pending(self.config.payment_status_poll_limit)
        except Exception:
            logger.error("Erro no banco de dados ao listar pagamentos pendentes.", exc_info=True)
            return

        for payment in payments:
            try:
                result = await self.payment_service.refresh_payment(payment["id"], "polling")
                if result.changed and result.payment and is_final_status(result.payment["status"]):
                    await self._notify(result.payment)
            except PaymentGatewayError as exc:
                logger.debug("Consulta de pagamento pendente %s falhou: %s", payment["id"], exc)
            except Exception:
                logger.warning("Falha ao consultar pagamento pendente %s.", payment["id"], exc_info=True)

    async def _notify(self, payment: dict) -> None:
        title = "✅ Pagamento confirmado!" if payment["status"] == PaymentStatus.PAID.value else "📌 Pagamento atualizado"
        text = "\n".join(
            [
                f"<b>{title}</b>",
                "",
                f"💰 Valor solicitado: <b>{html_escape(format_brl(payment['amount_cents']))}</b>",
                *self._fee_lines(payment),
                f"📌 Status: <b>{html_escape(status_label(payment['status']))}</b>",
                f"ID do pagamento: <code>{html_escape(payment['gateway_payment_id'])}</code>",
            ]
        )
        await self.bot.send_message(
            chat_id=payment["telegram_user_id"],
            text=text,
            parse_mode=ParseMode.HTML,
        )

    def _fee_lines(self, payment: dict) -> list[str]:
        if not payment.get("fee_percent_basis_points"):
            return []
        return [
            f"Taxa: <b>{html_escape(format_fee_percent(payment['fee_percent_basis_points']))}</b>",
            f"Valor da taxa: <b>{html_escape(format_brl(payment['fee_amount_cents']))}</b>",
            f"Valor líquido recebido: <b>{html_escape(format_brl(payment['net_amount_cents']))}</b>",
        ]
