from __future__ import annotations

import hmac
from typing import Any

from aiohttp import web
from telegram import Update
from telegram.constants import ParseMode

from .currency import format_brl, format_fee_percent
from .security import clean_text, get_logger, html_escape
from .status import PaymentStatus, is_final_status, map_gateway_status, status_label


logger = get_logger(__name__)


class WebServer:
    def __init__(self, config, telegram_application, payment_service):
        self.config = config
        self.telegram_application = telegram_application
        self.payment_service = payment_service
        self.app = web.Application(client_max_size=100 * 1024)
        self.runner: web.AppRunner | None = None
        self.site: web.TCPSite | None = None
        self._setup_routes()

    def _setup_routes(self) -> None:
        self.app.router.add_get("/health", self.health)
        self.app.router.add_post("/webhooks/payments/amazingpay", self.payment_webhook)
        if self.config.telegram_use_webhook:
            self.app.router.add_post(self.config.telegram_webhook_path, self.telegram_webhook)

    async def start(self) -> None:
        self.runner = web.AppRunner(self.app)
        await self.runner.setup()
        self.site = web.TCPSite(self.runner, self.config.host, self.config.port)
        await self.site.start()
        logger.info("Servidor HTTP iniciado em %s:%s.", self.config.host, self.config.port)

    async def stop(self) -> None:
        if self.runner:
            await self.runner.cleanup()

    async def health(self, _request: web.Request) -> web.Response:
        return web.json_response({"ok": True, "service": "telegram-amazingpay-bot-python"})

    async def telegram_webhook(self, request: web.Request) -> web.Response:
        try:
            data = await request.json()
        except Exception:
            logger.warning("Webhook do Telegram recebeu JSON invalido.")
            return web.json_response({"ok": False, "error": "INVALID_JSON"}, status=400)

        update = Update.de_json(data, self.telegram_application.bot)
        await self.telegram_application.update_queue.put(update)
        return web.json_response({"ok": True})

    async def payment_webhook(self, request: web.Request) -> web.Response:
        if not self._authorized(request):
            return web.json_response({"ok": False, "error": "UNAUTHORIZED"}, status=401)

        try:
            payload = await request.json()
        except Exception:
            logger.warning("Webhook de pagamento recebeu JSON invalido.")
            return web.json_response({"ok": False, "error": "INVALID_JSON"}, status=400)

        if not isinstance(payload, dict):
            logger.warning("Webhook de pagamento recebeu payload invalido.")
            return web.json_response({"ok": False, "error": "INVALID_PAYLOAD"}, status=400)

        pix_id, status = self._extract_payload(payload)
        if not pix_id or not status:
            logger.warning("Webhook de pagamento sem pix_id ou status.")
            return web.json_response({"ok": False, "error": "INVALID_PAYLOAD"}, status=400)

        if map_gateway_status(status) is None:
            logger.warning("Webhook de pagamento recebeu status desconhecido: %s.", status)
            return web.json_response({"ok": False, "error": "INVALID_STATUS"}, status=400)

        try:
            result = await self.payment_service.apply_gateway_status(
                pix_id,
                status,
                source="webhook",
                payload=payload,
            )
        except Exception:
            logger.error("Falha ao processar webhook de pagamento.", exc_info=True)
            return web.json_response({"ok": False, "error": "PROCESSING_FAILED"}, status=500)

        if not result.payment:
            return web.json_response({"ok": False, "error": "PAYMENT_NOT_FOUND"}, status=404)

        if result.changed:
            try:
                await self._notify_status_change(result.payment)
            except Exception:
                logger.warning("Pagamento atualizado, mas notificacao falhou.", exc_info=True)

        return web.json_response(
            {
                "ok": True,
                "paymentId": result.payment["id"],
                "status": result.payment["status"],
                "changed": result.changed,
            }
        )

    def _authorized(self, request: web.Request) -> bool:
        expected = self.config.payment_webhook_secret
        if not expected:
            return False

        authorization = request.headers.get("Authorization", "")
        bearer = authorization.removeprefix("Bearer ").strip() if authorization.startswith("Bearer ") else ""
        received = request.headers.get("x-webhook-secret", "") or bearer
        return hmac.compare_digest(received, expected)

    def _extract_payload(self, payload: dict[str, Any]) -> tuple[str, str]:
        pix_id = clean_text(
            payload.get("pixId")
            or payload.get("pix_id")
            or payload.get("paymentId")
            or payload.get("payment_id")
            or payload.get("id"),
            128,
        )
        status = clean_text(payload.get("status"), 32).lower()
        return pix_id, status

    async def _notify_status_change(self, payment: dict) -> None:
        if not is_final_status(payment["status"]):
            return

        title = "✅ Pagamento confirmado!" if payment["status"] == PaymentStatus.PAID.value else "📌 Pagamento atualizado"
        text = "\n".join(
            [
                f"<b>{title}</b>",
                "",
                f"💰 Valor solicitado: <b>{html_escape(format_brl(payment['amount_cents']))}</b>",
                *self._fee_lines(payment),
                f"📌 Status: <b>{html_escape(status_label(payment['status']))}</b>",
                f"ID do pagamento: <code>{html_escape(payment['gateway_payment_id'])}</code>",
            ]
        )
        await self.telegram_application.bot.send_message(
            chat_id=payment["telegram_user_id"],
            text=text,
            parse_mode=ParseMode.HTML,
        )

    def _fee_lines(self, payment: dict) -> list[str]:
        if not payment.get("fee_percent_basis_points"):
            return []
        return [
            f"Taxa: <b>{html_escape(format_fee_percent(payment['fee_percent_basis_points']))}</b>",
            f"Valor da taxa: <b>{html_escape(format_brl(payment['fee_amount_cents']))}</b>",
            f"Valor líquido recebido: <b>{html_escape(format_brl(payment['net_amount_cents']))}</b>",
        ]
