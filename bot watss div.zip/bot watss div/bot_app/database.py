from __future__ import annotations

import asyncio
import json
import sqlite3
from pathlib import Path
from typing import Any

from .status import PaymentStatus


SCHEMA = """
CREATE TABLE IF NOT EXISTS payments (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  telegram_user_id TEXT NOT NULL,
  telegram_username TEXT,
  telegram_name TEXT,
  amount_cents INTEGER NOT NULL CHECK (amount_cents BETWEEN 200 AND 50000),
  fee_percent_basis_points INTEGER NOT NULL DEFAULT 0 CHECK (
    fee_percent_basis_points = 0 OR fee_percent_basis_points BETWEEN 1500 AND 2000
  ),
  fee_amount_cents INTEGER NOT NULL DEFAULT 0 CHECK (fee_amount_cents >= 0),
  net_amount_cents INTEGER NOT NULL DEFAULT 0 CHECK (net_amount_cents >= 0),
  gateway_payment_id TEXT NOT NULL UNIQUE,
  payment_link TEXT,
  pix_code TEXT,
  status TEXT NOT NULL CHECK (status IN ('PENDING', 'PAID', 'EXPIRED', 'CANCELLED', 'FAILED')),
  idempotency_key TEXT NOT NULL UNIQUE,
  raw_gateway_response TEXT,
  created_at TEXT NOT NULL DEFAULT (datetime('now')),
  updated_at TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE INDEX IF NOT EXISTS idx_payments_user_created
  ON payments (telegram_user_id, created_at DESC);

CREATE INDEX IF NOT EXISTS idx_payments_status_created
  ON payments (status, created_at ASC);

CREATE TABLE IF NOT EXISTS payment_events (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  payment_id INTEGER NOT NULL,
  previous_status TEXT,
  new_status TEXT NOT NULL,
  source TEXT NOT NULL,
  payload TEXT,
  created_at TEXT NOT NULL DEFAULT (datetime('now')),
  FOREIGN KEY (payment_id) REFERENCES payments(id)
);

CREATE TRIGGER IF NOT EXISTS trg_payments_updated_at
AFTER UPDATE ON payments
FOR EACH ROW
BEGIN
  UPDATE payments SET updated_at = datetime('now') WHERE id = OLD.id;
END;

CREATE TABLE IF NOT EXISTS user_pix_keys (
  telegram_user_id TEXT PRIMARY KEY,
  telegram_username TEXT,
  telegram_name TEXT,
  key_type TEXT NOT NULL CHECK (key_type IN ('CPF', 'CNPJ', 'EMAIL', 'PHONE', 'EVP')),
  encrypted_key TEXT NOT NULL,
  key_hash TEXT NOT NULL,
  masked_key TEXT NOT NULL,
  created_at TEXT NOT NULL DEFAULT (datetime('now')),
  updated_at TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE TRIGGER IF NOT EXISTS trg_user_pix_keys_updated_at
AFTER UPDATE ON user_pix_keys
FOR EACH ROW
BEGIN
  UPDATE user_pix_keys SET updated_at = datetime('now') WHERE telegram_user_id = OLD.telegram_user_id;
END;
"""


def _row_to_dict(row: sqlite3.Row | None) -> dict[str, Any] | None:
    return dict(row) if row else None


def _json(value: Any) -> str | None:
    if value is None:
        return None
    return json.dumps(value, ensure_ascii=False)


class PaymentRepository:
    def __init__(self, database_path: Path):
        self.database_path = database_path
        self.database_path.parent.mkdir(parents=True, exist_ok=True)
        self._connection = sqlite3.connect(database_path, check_same_thread=False)
        self._connection.row_factory = sqlite3.Row
        self._connection.execute("PRAGMA foreign_keys = ON")
        self._connection.execute("PRAGMA journal_mode = WAL")
        self._lock = asyncio.Lock()

    async def initialize(self) -> None:
        async with self._lock:
            self._connection.executescript(SCHEMA)
            self._migrate_payments_locked()
            self._connection.commit()

    async def close(self) -> None:
        async with self._lock:
            self._connection.close()

    async def create_payment(self, data: dict[str, Any]) -> dict[str, Any]:
        async with self._lock:
            cursor = self._connection.execute(
                """
                INSERT INTO payments (
                  telegram_user_id,
                  telegram_username,
                  telegram_name,
                  amount_cents,
                  fee_percent_basis_points,
                  fee_amount_cents,
                  net_amount_cents,
                  gateway_payment_id,
                  payment_link,
                  pix_code,
                  status,
                  idempotency_key,
                  raw_gateway_response
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                """,
                (
                    data["telegram_user_id"],
                    data.get("telegram_username"),
                    data.get("telegram_name"),
                    data["amount_cents"],
                    data["fee_percent_basis_points"],
                    data["fee_amount_cents"],
                    data["net_amount_cents"],
                    data["gateway_payment_id"],
                    data.get("payment_link"),
                    data.get("pix_code"),
                    data["status"],
                    data["idempotency_key"],
                    _json(data.get("raw_gateway_response")),
                ),
            )
            self._connection.commit()
            return await self._get_by_id_locked(cursor.lastrowid)

    async def upsert_pix_key(self, data: dict[str, Any]) -> dict[str, Any]:
        async with self._lock:
            self._connection.execute(
                """
                INSERT INTO user_pix_keys (
                  telegram_user_id,
                  telegram_username,
                  telegram_name,
                  key_type,
                  encrypted_key,
                  key_hash,
                  masked_key
                ) VALUES (?, ?, ?, ?, ?, ?, ?)
                ON CONFLICT(telegram_user_id) DO UPDATE SET
                  telegram_username = excluded.telegram_username,
                  telegram_name = excluded.telegram_name,
                  key_type = excluded.key_type,
                  encrypted_key = excluded.encrypted_key,
                  key_hash = excluded.key_hash,
                  masked_key = excluded.masked_key
                """,
                (
                    data["telegram_user_id"],
                    data.get("telegram_username"),
                    data.get("telegram_name"),
                    data["key_type"],
                    data["encrypted_key"],
                    data["key_hash"],
                    data["masked_key"],
                ),
            )
            self._connection.commit()
            return await self._get_pix_key_locked(data["telegram_user_id"])

    async def get_pix_key(self, telegram_user_id: int | str) -> dict[str, Any] | None:
        async with self._lock:
            return await self._get_pix_key_locked(str(telegram_user_id))

    async def delete_pix_key(self, telegram_user_id: int | str) -> bool:
        async with self._lock:
            cursor = self._connection.execute(
                "DELETE FROM user_pix_keys WHERE telegram_user_id = ?",
                (str(telegram_user_id),),
            )
            self._connection.commit()
            return cursor.rowcount > 0

    async def get_by_id(self, payment_id: int) -> dict[str, Any] | None:
        async with self._lock:
            return await self._get_by_id_locked(payment_id)

    async def get_by_idempotency_key(self, key: str) -> dict[str, Any] | None:
        async with self._lock:
            row = self._connection.execute(
                "SELECT * FROM payments WHERE idempotency_key = ?",
                (key,),
            ).fetchone()
            return _row_to_dict(row)

    async def get_by_gateway_payment_id(self, gateway_payment_id: str) -> dict[str, Any] | None:
        async with self._lock:
            row = self._connection.execute(
                "SELECT * FROM payments WHERE gateway_payment_id = ?",
                (gateway_payment_id,),
            ).fetchone()
            return _row_to_dict(row)

    async def get_for_user(self, payment_id: int, telegram_user_id: int | str) -> dict[str, Any] | None:
        async with self._lock:
            row = self._connection.execute(
                "SELECT * FROM payments WHERE id = ? AND telegram_user_id = ?",
                (payment_id, str(telegram_user_id)),
            ).fetchone()
            return _row_to_dict(row)

    async def list_for_user(self, telegram_user_id: int | str, limit: int, offset: int) -> list[dict[str, Any]]:
        async with self._lock:
            rows = self._connection.execute(
                """
                SELECT * FROM payments
                WHERE telegram_user_id = ?
                ORDER BY datetime(created_at) DESC, id DESC
                LIMIT ? OFFSET ?
                """,
                (str(telegram_user_id), limit, offset),
            ).fetchall()
            return [dict(row) for row in rows]

    async def count_for_user(self, telegram_user_id: int | str) -> int:
        async with self._lock:
            row = self._connection.execute(
                "SELECT COUNT(*) AS total FROM payments WHERE telegram_user_id = ?",
                (str(telegram_user_id),),
            ).fetchone()
            return int(row["total"])

    async def list_pending(self, limit: int) -> list[dict[str, Any]]:
        async with self._lock:
            rows = self._connection.execute(
                """
                SELECT * FROM payments
                WHERE status = 'PENDING'
                ORDER BY datetime(created_at) ASC, id ASC
                LIMIT ?
                """,
                (limit,),
            ).fetchall()
            return [dict(row) for row in rows]

    async def update_status(
        self,
        payment_id: int,
        new_status: PaymentStatus,
        source: str,
        payload: Any = None,
    ) -> dict[str, Any] | None:
        async with self._lock:
            payment = await self._get_by_id_locked(payment_id)
            if not payment:
                return None

            if payment["status"] != new_status.value:
                self._connection.execute(
                    "UPDATE payments SET status = ? WHERE id = ?",
                    (new_status.value, payment_id),
                )

            self._connection.execute(
                """
                INSERT INTO payment_events (payment_id, previous_status, new_status, source, payload)
                VALUES (?, ?, ?, ?, ?)
                """,
                (payment_id, payment["status"], new_status.value, source, _json(payload)),
            )
            self._connection.commit()
            return await self._get_by_id_locked(payment_id)

    async def _get_by_id_locked(self, payment_id: int) -> dict[str, Any] | None:
        row = self._connection.execute("SELECT * FROM payments WHERE id = ?", (payment_id,)).fetchone()
        return _row_to_dict(row)

    async def _get_pix_key_locked(self, telegram_user_id: int | str) -> dict[str, Any] | None:
        row = self._connection.execute(
            "SELECT * FROM user_pix_keys WHERE telegram_user_id = ?",
            (str(telegram_user_id),),
        ).fetchone()
        return _row_to_dict(row)

    def _migrate_payments_locked(self) -> None:
        columns = {
            row["name"]
            for row in self._connection.execute("PRAGMA table_info(payments)").fetchall()
        }
        migrations = {
            "fee_percent_basis_points": (
                "ALTER TABLE payments ADD COLUMN fee_percent_basis_points INTEGER NOT NULL DEFAULT 0"
            ),
            "fee_amount_cents": "ALTER TABLE payments ADD COLUMN fee_amount_cents INTEGER NOT NULL DEFAULT 0",
            "net_amount_cents": "ALTER TABLE payments ADD COLUMN net_amount_cents INTEGER NOT NULL DEFAULT 0",
        }
        for column, statement in migrations.items():
            if column not in columns:
                self._connection.execute(statement)

        self._connection.execute(
            """
            UPDATE payments
            SET net_amount_cents = amount_cents - fee_amount_cents
            WHERE net_amount_cents = 0
            """
        )
