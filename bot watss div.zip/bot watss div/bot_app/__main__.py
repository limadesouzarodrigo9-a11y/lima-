import asyncio
import signal

from telegram import Update
from telegram.ext import Application

from .amazingpay import AmazingPayClient
from .config import load_config
from .database import PaymentRepository
from .payments import PaymentService
from .poller import StatusPoller
from .security import get_logger, setup_logging
from .telegram_bot import build_application
from .webserver import WebServer


async def _start_telegram(application: Application, config) -> None:
    await application.initialize()
    await application.start()

    if config.telegram_use_webhook:
        webhook_url = config.telegram_webhook_url
        await application.bot.set_webhook(webhook_url)
        get_logger(__name__).info("Telegram iniciado em modo webhook: %s", config.telegram_webhook_path)
        return

    await application.bot.delete_webhook(drop_pending_updates=False)
    await application.updater.start_polling(allowed_updates=Update.ALL_TYPES)
    get_logger(__name__).info("Telegram iniciado em modo polling.")


async def _stop_telegram(application: Application, config) -> None:
    if not config.telegram_use_webhook and application.updater.running:
        await application.updater.stop()

    await application.stop()
    await application.shutdown()


async def async_main() -> None:
    config = load_config()
    setup_logging(config)
    logger = get_logger(__name__)

    repository = PaymentRepository(config.database_path)
    await repository.initialize()

    async with AmazingPayClient(config.payment_api_url, config.payment_api_key) as client:
        payment_service = PaymentService(repository, client, config)
        application = build_application(config, payment_service)
        web_server = WebServer(config, application, payment_service)
        poller = StatusPoller(config, payment_service, application.bot)

        await web_server.start()
        await _start_telegram(application, config)
        poller.start()

        stop_event = asyncio.Event()

        def request_shutdown(*_args) -> None:
            stop_event.set()

        for sig in (signal.SIGINT, signal.SIGTERM):
            try:
                signal.signal(sig, request_shutdown)
            except ValueError:
                pass

        logger.info("Bot pronto. Pressione Ctrl+C para encerrar.")
        await stop_event.wait()

        logger.info("Encerrando...")
        await poller.stop()
        await _stop_telegram(application, config)
        await web_server.stop()
        await repository.close()


def run() -> None:
    asyncio.run(async_main())
