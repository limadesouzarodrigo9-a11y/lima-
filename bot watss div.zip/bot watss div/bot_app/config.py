from __future__ import annotations

import os
from dataclasses import dataclass
from pathlib import Path

from dotenv import load_dotenv

from .currency import parse_fee_percent_to_basis_points


def _bool(value: str | None, default: bool = False) -> bool:
    if value is None or value == "":
        return default
    return value.strip().lower() in {"1", "true", "yes", "on", "sim"}


def _int(value: str | None, default: int) -> int:
    try:
        return int(value) if value not in (None, "") else default
    except ValueError:
        return default


def _database_path(value: str | None) -> Path:
    raw_path = value or "./data/payments.sqlite"
    return Path(raw_path).expanduser().resolve()


@dataclass(frozen=True)
class Config:
    telegram_bot_token: str
    payment_api_key: str
    payment_api_url: str
    database_path: Path
    host: str
    port: int
    log_level: str
    payment_webhook_secret: str
    payment_status_poll_interval_seconds: int
    payment_status_poll_limit: int
    telegram_use_webhook: bool
    webhook_url: str
    telegram_webhook_path: str
    payment_fee_basis_points: int
    pix_key_encryption_secret: str

    @property
    def telegram_webhook_url(self) -> str:
        return f"{self.webhook_url.rstrip('/')}{self.telegram_webhook_path}"


def load_config() -> Config:
    load_dotenv()

    config = Config(
        telegram_bot_token=os.getenv("TELEGRAM_BOT_TOKEN", "").strip(),
        payment_api_key=os.getenv("PAYMENT_API_KEY", "").strip(),
        payment_api_url=os.getenv("PAYMENT_API_URL", "https://amazingpay.space").strip(),
        database_path=_database_path(os.getenv("DATABASE_PATH")),
        host=os.getenv("HOST", "0.0.0.0").strip(),
        port=_int(os.getenv("PORT"), 3000),
        log_level=os.getenv("LOG_LEVEL", "INFO").strip().upper(),
        payment_webhook_secret=os.getenv("PAYMENT_WEBHOOK_SECRET", "").strip(),
        payment_status_poll_interval_seconds=_int(
            os.getenv("PAYMENT_STATUS_POLL_INTERVAL_SECONDS"), 60
        ),
        payment_status_poll_limit=_int(os.getenv("PAYMENT_STATUS_POLL_LIMIT"), 20),
        telegram_use_webhook=_bool(os.getenv("TELEGRAM_USE_WEBHOOK"), False),
        webhook_url=os.getenv("WEBHOOK_URL", "").strip(),
        telegram_webhook_path=os.getenv("TELEGRAM_WEBHOOK_PATH", "/telegram/webhook").strip(),
        payment_fee_basis_points=parse_fee_percent_to_basis_points(
            os.getenv("PAYMENT_FEE_PERCENT")
        ),
        pix_key_encryption_secret=os.getenv("PIX_KEY_ENCRYPTION_SECRET", "").strip(),
    )

    missing = []
    if not config.telegram_bot_token:
        missing.append("TELEGRAM_BOT_TOKEN")
    if not config.payment_api_key:
        missing.append("PAYMENT_API_KEY")
    if not config.payment_api_url:
        missing.append("PAYMENT_API_URL")
    if not config.pix_key_encryption_secret:
        missing.append("PIX_KEY_ENCRYPTION_SECRET")
    if missing:
        raise RuntimeError(f"Variaveis ausentes no .env: {', '.join(missing)}")

    if len(config.pix_key_encryption_secret) < 32:
        raise RuntimeError("PIX_KEY_ENCRYPTION_SECRET deve ter pelo menos 32 caracteres.")

    if config.telegram_use_webhook and not config.webhook_url:
        raise RuntimeError("WEBHOOK_URL e obrigatoria quando TELEGRAM_USE_WEBHOOK=true.")
    if not config.telegram_webhook_path.startswith("/"):
        raise RuntimeError("TELEGRAM_WEBHOOK_PATH deve comecar com '/'.")
    if config.port <= 0:
        raise RuntimeError("PORT deve ser um numero positivo.")

    return config
