# Bot Telegram AmazingPay em Python

Bot em Python para gerar cobranças PIX no Telegram usando a API configurada da AmazingPay.

## O que vem pronto

- Comandos `/start`, `/pagamento`, `/pix`, `/chavepix`, `/cancelar`, `/meuspagamentos` e `/ajuda`.
- Validação de valores entre R$ 2,00 e R$ 500,00.
- Confirmação antes de criar cobrança, exibindo valor solicitado, taxa, valor da taxa e valor líquido.
- Taxa configurável por `.env`, validada entre 15% e 20%.
- Cadastro, consulta mascarada, alteração e remoção de chave PIX por usuário.
- Chaves PIX criptografadas no SQLite e nunca exibidas completas depois do cadastro.
- SQLite nativo, sem depender de servidor de banco.
- Rate limit por usuário.
- Histórico com paginação.
- Criação de PIX pela AmazingPay.
- Consulta manual e automática de status.
- Webhook HTTP protegido por segredo para atualização de pagamentos.
- Tokens e chaves somente por `.env`.
- Logs de API sem spam: sucesso/erro só aparecem quando o estado muda ou quando o problema muda.

> A integração AmazingPay existente no código usa `GET /createPix` e `GET /pix/{pixId}`. Não foi adicionado endpoint fictício para registrar/validar chave PIX no provedor, porque essa informação não existe no projeto atual. A chave PIX do usuário fica salva com segurança no banco para uso interno/futuro.

## Instalar no Windows

No PowerShell, dentro desta pasta:

```powershell
py -m venv .venv
.\.venv\Scripts\Activate.ps1
py -m pip install --upgrade pip
py -m pip install -r requirements.txt
```

Se o PowerShell bloquear a ativação da venv:

```powershell
Set-ExecutionPolicy -Scope CurrentUser RemoteSigned
.\.venv\Scripts\Activate.ps1
```

## Configurar

Crie o arquivo `.env` a partir do exemplo e preencha os segredos:

```powershell
Copy-Item .env.example .env
notepad .env
```

Variáveis principais:

```env
TELEGRAM_BOT_TOKEN=seu_token_do_telegram
PAYMENT_API_KEY=sua_chave_da_amazingpay
PAYMENT_API_URL=https://amazingpay.space
PAYMENT_FEE_PERCENT=15
PIX_KEY_ENCRYPTION_SECRET=gere_um_segredo_forte_com_32_ou_mais_caracteres
DATABASE_PATH=./data/payments.sqlite
PAYMENT_WEBHOOK_SECRET=um_segredo_forte
```

`PAYMENT_FEE_PERCENT` aceita valores de 15 até 20. Exemplos: `15`, `17.5`, `20`.

`PIX_KEY_ENCRYPTION_SECRET` deve ser estável e secreto. Se ele mudar, as chaves PIX antigas não poderão ser descriptografadas.

## Banco de dados

As alterações são aplicadas automaticamente quando o bot inicia:

- Novas colunas em `payments`: `fee_percent_basis_points`, `fee_amount_cents`, `net_amount_cents`.
- Nova tabela `user_pix_keys`.

Não é necessário rodar comando manual de migração. Faça backup de `data/payments.sqlite` antes de subir em produção.

## Executar

```powershell
.\.venv\Scripts\Activate.ps1
python main.py
```

O bot usa polling do Telegram por padrão e também sobe um servidor HTTP:

```txt
GET http://localhost:3000/health
POST http://localhost:3000/webhooks/payments/amazingpay
```

## Webhook da AmazingPay

A rota pronta é:

```txt
POST /webhooks/payments/amazingpay
Header: x-webhook-secret: seu_segredo
```

Payload aceito:

```json
{
  "pixId": "ID_DO_PIX",
  "status": "verified"
}
```

Status mapeados:

- `waiting` -> `PENDING`
- `verified` -> `PAID`
- `expired` -> `EXPIRED`
- `cancelled` -> `CANCELLED`
- `failed` -> `FAILED`

Webhooks repetidos com o mesmo status retornam `changed: false` e não disparam nova notificação.

## Como testar

- API funcionando: gere um pagamento pelo Telegram e confirme que o terminal mostra uma vez `✅ API funcionando normalmente`.
- API com erro: configure temporariamente `PAYMENT_API_URL` inválida e gere/consulte um pagamento; o log deve mostrar `❌ Erro na API: ...` sem repetir a cada ciclo.
- Cadastro de PIX: use `/pix`, clique em cadastrar, envie CPF/CNPJ/e-mail/telefone/UUID, confirme e veja a chave mascarada.
- Alterar/remover PIX: use `/pix`, escolha alterar ou remover e confirme o fluxo.
- Depósito/pagamento: use `/pagamento`, informe o valor e confirme somente depois de revisar taxa e líquido.
- Cálculo da taxa: teste `PAYMENT_FEE_PERCENT=15` e `PAYMENT_FEE_PERCENT=20`; R$ 100,00 deve gerar taxa de R$ 15,00 ou R$ 20,00.
- Confirmação do pagamento: envie webhook `verified` com `pixId` válido ou use o botão de verificar status.
- Pagamento duplicado: envie o mesmo webhook duas vezes; a segunda resposta deve vir com `changed: false`.
- API indisponível: interrompa a rede/base URL e aguarde o polling; o poller não deve ficar spamando erro para cada pagamento.

## Verificar sintaxe

```powershell
python scripts/check.py
```

## Segurança

- Rotacione qualquer token que tenha sido enviado em conversa.
- Use HTTPS em produção.
- Configure `PAYMENT_WEBHOOK_SECRET`.
- Configure `PIX_KEY_ENCRYPTION_SECRET` e guarde fora do código.
- Mantenha `.env` fora do Git.
- Os logs ocultam os segredos conhecidos e não registram a chave PIX completa do usuário.
